import { Routes } from '@angular/router';
import { AnimalComponent } from './components/animal-component/animal-component';

export const routes: Routes = [
    {path:'inicio', component: AnimalComponent}
];
